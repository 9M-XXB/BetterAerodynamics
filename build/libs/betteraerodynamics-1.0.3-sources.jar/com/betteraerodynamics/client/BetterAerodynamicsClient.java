package com.betteraerodynamics.client;

import com.betteraerodynamics.ElytraPhysics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-side HUD: displays altitude in overlay, logs all flight data.
 */
public class BetterAerodynamicsClient implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("betteraero-hud");

    @Override
    public void onInitializeClient() {
        LOG.info("HUD client registered");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!ElytraPhysics.hudEnabled) return;
            if (client.player == null || client.level == null) return;

            long tick = client.level.getGameTime();
            if (tick % 20 != 0) return; // once per second

            int sea = client.level.getSeaLevel();
            double y = client.player.getY();
            double top = 320.0;
            double span = Math.max(1.0, top - sea);
            double feet = Math.max(-2000.0, Math.min(100000.0, (y - sea) / span * 29031.0));

            double spd = ElytraPhysics.lastSpeedFtS;
            double lift = ElytraPhysics.lastLiftLbf;
            double drag = ElytraPhysics.lastDragLbf;
            boolean stalled = ElytraPhysics.lastStalled;
            boolean flying = client.player.isFallFlying();

            // Always log flight data — visible in latest.log
            if (spd > 1) {
                LOG.info("FLIGHT Alt={}ft Spd={}ft/s L={}lbf D={}lbf stall={} isFallFlying={}",
                    (int)feet, (int)spd, (int)lift, (int)drag, stalled, flying);
            } else {
                LOG.info("FLIGHT Alt={}ft Spd=0 (grounded/static)", (int)feet);
            }

            // Overlay: altitude always, flight data only when values present
            String msg;
            if (spd > 1) {
                String stallStr = stalled ? " !!STALL!!" : "";
                msg = String.format("Alt %.0f ft | Spd %.0f ft/s | L %.0f D %.0f lbf%s",
                    feet, spd, lift, drag, stallStr);
            } else if (client.player.isUnderWater()) {
                double depth = Math.max(0, (sea - client.player.getEyeY()) * 3.28);
                msg = String.format("Alt %.0f ft | Depth %.0f ft", feet, depth);
            } else {
                msg = String.format("Alt %.0f ft | /aerohud", feet);
            }

            client.player.sendOverlayMessage(Component.literal(msg));
        });
    }
}
