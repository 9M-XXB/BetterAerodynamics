package com.betteraerodynamics.mixin;

import com.betteraerodynamics.ElytraPhysics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to inject the aerodynamic HUD into the vanilla GUI render.
 */
@Mixin(Gui.class)
public class GuiMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void renderAeroHud(GuiGraphicsExtractor graphics, DeltaTracker delta, CallbackInfo ci) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;
        if (client.options.hideGui) return;
        if (!ElytraPhysics.hudEnabled) return;

        int seaLevel = client.level.getSeaLevel();
        double y = client.player.getY();
        double top = 320.0;
        double span = Math.max(1.0, top - seaLevel);
        double normalized = (y - seaLevel) / span;
        double feet = normalized * 29031.0;
        feet = Math.max(-2000.0, Math.min(100000.0, feet));
        double meters = feet * 0.3048;

        int right = graphics.guiWidth() - 10;
        int yPos = 20;
        int color = 0xFFFFFF;
        int stallColor = 0xFF4444;

        // Altitude line
        String altText = String.format("Alt: %.0f ft / %.0f m", feet, meters);
        graphics.text(client.font, altText, right - client.font.width(altText), yPos, color);
        yPos += 12;

        // Aerodynamic data (only show when flying)
        if (client.player.isFallFlying() && ElytraPhysics.lastSpeedFtS > 1) {
            // Speed
            String speedText = String.format("Spd: %.0f ft/s", ElytraPhysics.lastSpeedFtS);
            graphics.text(client.font, speedText, right - client.font.width(speedText), yPos, color);
            yPos += 12;

            // Lift/Drag
            String ldText;
            int ldColor = color;
            if (ElytraPhysics.lastStalled) {
                ldText = "!! STALL !!";
                ldColor = stallColor;
            } else {
                ldText = String.format("L: %.0f  D: %.0f lbf  Cf: %.4f",
                    ElytraPhysics.lastLiftLbf, ElytraPhysics.lastDragLbf, ElytraPhysics.lastCd0);
            }
            graphics.text(client.font, ldText, right - client.font.width(ldText), yPos, ldColor);
            yPos += 12;

            // L/D ratio
            if (!ElytraPhysics.lastStalled && ElytraPhysics.lastDragLbf > 0.1) {
                double ldRatio = ElytraPhysics.lastLiftLbf / ElytraPhysics.lastDragLbf;
                String ratioText = String.format("L/D: %.1f", ldRatio);
                graphics.text(client.font, ratioText, right - client.font.width(ratioText), yPos, color);
            }
        }
    }
}
