package com.betteraerodynamics.aero;

import com.betteraerodynamics.AtmosphereManager;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;

/**
 * 3D wing physics — connects Minecraft entities to aerodynamic forces.
 *
 * <p>Computes lift and drag on a wing moving through the MC atmosphere.
 * Angle of attack is derived from the player's velocity relative to
 * their horizontal look direction.
 *
 * <p>Optimization: stall angle pre-converted to radians in WingConfig;
 * early zero-velocity bailout avoids all downstream computation.
 */
public class WingPhysics {

    // === Configuration (stall angle stored in radians) ===

    public record WingConfig(
        double wingArea,
        double aspectRatio,
        double oswaldEfficiency,
        double cd0,
        double clMax,
        /** Stall angle in RADIANS (pre-converted, no runtime toRadians). */
        double stallAngleRad,
        double maxLoad
    ) {
        /** Default glider: 10 ft², AR=6. */
        public static final WingConfig GLIDER = new WingConfig(
            10.0, 6.0, 0.85, 0.008, 1.5, 0.261799, 500.0  // 15° in rad
        );
        /** Small aircraft: 25 ft², AR=7. */
        public static final WingConfig SMALL_AIRCRAFT = new WingConfig(
            25.0, 7.0, 0.80, 0.012, 1.4, 0.244346, 1200.0 // 14° in rad
        );
    }

    // === Result ===

    public record WingForces(
        double lift, double drag, double dynamicPressure,
        double angleOfAttack, double clWing, double cdWing,
        boolean stalled
    ) {}

    // === Computation ===

    /**
     * Compute wing forces from player flight state.
     * Hot path — called every tick for flying entities.
     */
    public static WingForces computeForces(ServerLevel world, Player player,
                                            WingConfig config, AirfoilProfile airfoil) {
        // Early exit: stationary → zero forces, zero GC
        double vx = player.getDeltaMovement().x;
        double vy = player.getDeltaMovement().y;
        double vz = player.getDeltaMovement().z;
        double v2 = vx * vx + vy * vy + vz * vz;

        if (v2 < 0.01) {
            return new WingForces(0, 0, 0, 0, 0, 0, false);
        }

        double velocity = Math.sqrt(v2);
        double density = AtmosphereManager.getDensity(world, player);

        // Angle of attack from velocity vs. horizontal look direction
        double yawRad = Math.toRadians(player.getYRot());
        double horizSpeed = vx * Math.sin(yawRad) + vz * Math.cos(yawRad);
        double alpha = Math.atan2(-vy, Math.abs(horizSpeed) + 0.001);
        alpha = Mth.clamp(alpha, -0.785398, 0.785398); // ±45° clamp (pre-computed)

        // Effective α with zero-lift correction
        double alpha0 = (airfoil != null) ? airfoil.zeroLiftAngle() : 0.0;
        double effAlpha = alpha - alpha0;

        // Stall check (uses pre-converted radian stall angle)
        boolean stalled = Math.abs(effAlpha) > config.stallAngleRad;
        double cl;
        if (stalled) {
            cl = Math.signum(effAlpha) * config.clMax * 0.7;
        } else {
            double temperatureR = AtmosphereManager.getTemperature(world, player);
            double speedOfSound = AerodynamicsEngine.speedOfSound(temperatureR);
            cl = AerodynamicsEngine.sectionCoeffs(effAlpha, 0, velocity, speedOfSound).cl();
        }
        cl = Mth.clamp(cl, -config.clMax, config.clMax);

        // 3D wing conversion
        AerodynamicsEngine.WingCoefficients wing =
            AerodynamicsEngine.wingCoefficients(
                cl, config.cd0, config.aspectRatio, config.oswaldEfficiency);

        // Forces: L/D = ½ρV²·S·CL/CD
        double q = 0.5 * density * velocity * velocity;
        double lift = q * config.wingArea * wing.clWing();
        double drag = q * config.wingArea * wing.cdWing();

        if (lift > config.maxLoad) lift = config.maxLoad;

        return new WingForces(lift, drag, q, effAlpha, wing.clWing(), wing.cdWing(), stalled);
    }

    /** Compute with default symmetric airfoil (α₀ = 0). */
    public static WingForces computeForces(ServerLevel world, Player player, WingConfig config) {
        return computeForces(world, player, config, null);
    }
}
