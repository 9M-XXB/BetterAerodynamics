package com.betteraerodynamics.client;

import net.fabricmc.api.ClientModInitializer;

/**
 * Client initializer (placeholder).
 * HUD rendering is handled by {@link com.betteraerodynamics.mixin.GuiMixin}.
 */
public class BetterAerodynamicsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
    }
}
