package com.betteraerodynamics.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to inject the altitude HUD into the vanilla GUI render.
 * Fabric removed HudRenderCallback in MC 1.21.2, so we mix into Gui directly.
 */
@Mixin(Gui.class)
public class GuiMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void renderAltimeter(GuiGraphicsExtractor graphics, DeltaTracker delta, CallbackInfo ci) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;
        if (client.options.hideGui) return;

        int seaLevel = client.level.getSeaLevel();
        double y = client.player.getY();
        double top = 320.0;
        double span = Math.max(1.0, top - seaLevel);
        double normalized = (y - seaLevel) / span;
        double feet = normalized * 29031.0;
        feet = Math.max(-2000.0, Math.min(100000.0, feet));
        double meters = feet * 0.3048;

        String text = String.format("Alt: %.0f ft / %.0f m", feet, meters);

        int textWidth = client.font.width(text);
        int x = graphics.guiWidth() - 10 - textWidth;
        int yPos = 20;

        graphics.text(client.font, text, x, yPos, 0xFFFFFF);
    }
}
