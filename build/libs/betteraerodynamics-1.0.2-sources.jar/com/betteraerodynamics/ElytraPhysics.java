package com.betteraerodynamics;

import com.betteraerodynamics.aero.AirfoilProfile;
import com.betteraerodynamics.aero.BoundaryLayer;
import com.betteraerodynamics.aero.WingPhysics;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Bridges the aerodynamics engine into Minecraft elytra flight.
 *
 * <p>Every tick, for an elytra-flying player:
 * <ol>
 *   <li>Compute wing lift & drag via {@link WingPhysics}</li>
 *   <li>Every 10 ticks, recompute boundary layer for real-time skin friction</li>
 *   <li>Convert lbf → Minecraft velocity units</li>
 *   <li>Apply drag opposite to velocity, lift upward</li>
 * </ol>
 */
public class ElytraPhysics {

    /** Base wing config for elytra (cd0 overridden by boundary layer). */
    private static final WingPhysics.WingConfig BASE_CONFIG = new WingPhysics.WingConfig(
        15.0,    // wingArea (ft²)
        5.0,     // aspectRatio
        0.75,    // oswaldEfficiency
        0.010,   // cd0 — fallback, usually overridden by BL
        1.3,     // clMax
        0.261799, // stallAngle (15° in radians)
        800.0    // maxLoad (lbf)
    );

    /** NACA 2412: 2% camber, 12% thickness. */
    private static final AirfoilProfile ELYTRA_AIRFOIL = new AirfoilProfile("2412", 200);

    /** Conversion: lbf → Minecraft velocity delta per tick. */
    private static final double LBF_TO_MC = 0.00008;

    /** Minimum speed (ft/s). */
    private static final double MIN_SPEED_FT_S = 20.0;

    /** BL recompute interval (ticks). */
    private static final int BL_INTERVAL = 10;

    // Cached boundary layer
    private static BoundaryLayer.BLResult cachedBL;
    private static int tickCounter;

    /**
     * Apply aerodynamic lift and drag to an elytra-flying player.
     */
    public static void applyToPlayer(ServerLevel world, Player player) {
        if (!player.isFallFlying()) return;
        if (player.onGround()) return;

        Vec3 velocity = player.getDeltaMovement();
        double speedBlocksPerTick = velocity.length();
        double speedFtS = speedBlocksPerTick * 3.28084 * 20.0;

        if (speedFtS < MIN_SPEED_FT_S) return;

        // Recompute boundary layer periodically
        tickCounter++;
        double cd0 = BASE_CONFIG.cd0();
        if (tickCounter % BL_INTERVAL == 0 || cachedBL == null) {
            double temperatureR = AtmosphereManager.getTemperature(world, player);
            double nu = BoundaryLayer.kinematicViscosity(temperatureR);
            // Chord ≈ sqrt(wingArea / aspectRatio) ≈ √(15/5) ≈ 1.73 ft
            double chord = Math.sqrt(BASE_CONFIG.wingArea() / BASE_CONFIG.aspectRatio());
            cachedBL = BoundaryLayer.solve(ELYTRA_AIRFOIL, chord, speedFtS, nu, 0.02);
            cd0 = Math.max(cachedBL.totalCf(), 0.003); // floor at 0.003
        } else if (cachedBL != null) {
            cd0 = Math.max(cachedBL.totalCf(), 0.003);
        }

        // Build config with real-time cd0
        WingPhysics.WingConfig config = new WingPhysics.WingConfig(
            BASE_CONFIG.wingArea(), BASE_CONFIG.aspectRatio(),
            BASE_CONFIG.oswaldEfficiency(), cd0,
            BASE_CONFIG.clMax(), BASE_CONFIG.stallAngleRad(), BASE_CONFIG.maxLoad());

        WingPhysics.WingForces forces = WingPhysics.computeForces(
            world, player, config, ELYTRA_AIRFOIL);

        double dragLbf = forces.drag();
        double liftLbf = forces.lift();

        if (forces.stalled()) {
            dragLbf *= 2.5;
            liftLbf = 0;
        }

        double dragMc = Math.min(dragLbf * LBF_TO_MC, 0.15);
        double liftMc = Math.min(liftLbf * LBF_TO_MC, 0.12);

        if (speedBlocksPerTick > 0.001) {
            player.addDeltaMovement(velocity.normalize().scale(-dragMc));
        }

        if (liftMc > 0) {
            player.addDeltaMovement(new Vec3(0, liftMc, 0));
        }
    }
}
