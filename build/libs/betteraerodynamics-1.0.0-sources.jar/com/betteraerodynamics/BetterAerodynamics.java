package com.betteraerodynamics;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableSource;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BetterAerodynamics implements ModInitializer {
	public static final String MOD_ID = "betteraerodynamics";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// Item Identifiers for pressure suit pieces
	public static final Identifier PRESSURE_SUIT_HELMET = id("atmosphere_suit_helmet");
	public static final Identifier PRESSURE_SUIT_CHESTPLATE = id("atmosphere_suit_chestplate");
	public static final Identifier PRESSURE_SUIT_LEGGINGS = id("atmosphere_suit_leggings");
	public static final Identifier PRESSURE_SUIT_BOOTS = id("atmosphere_suit_boots");

	// Enchantment identifier
	public static final Identifier ENCHANTMENT_ID = id("pressure_seal");

	// Material items
	public static final Identifier CARBON_FIBER = id("carbon_fiber");
	public static final Identifier CARBON_FIBER_PLATE = id("carbon_fiber_plate");

	// Registered item instances (populated during init)
	public static Item pressureSuitHelmet;
	public static Item pressureSuitChestplate;
	public static Item pressureSuitLeggings;
	public static Item pressureSuitBoots;
	public static Item carbonFiberItem;
	public static Item carbonFiberPlateItem;

	/** Loot table path suffixes where pressure suit pieces can randomly appear. */
	private static final String[] LOOT_TABLE_PATHS = {
		"village/village_armorer",
		"village/village_weaponsmith",
		"village/village_toolsmith",
		"abandoned_mineshaft",
		"shipwreck_treasure",
		"buried_treasure"
	};

	private static boolean isTargetTable(ResourceKey<?> key) {
		String s = key.toString();
		for (String path : LOOT_TABLE_PATHS) {
			if (s.contains(path)) return true;
		}
		return false;
	}

	@Override
	public void onInitialize() {
		LOGGER.info("Better Aerodynamics initialized!");

		// Create ArmorMaterial for pressure suit (leather-tier stats, halved)
		var armorMaterial = new ArmorMaterial(
			5, // durability (matches leather: helmet=55, chest=80, legs=75, boots=65)
			java.util.Map.of(
				ArmorType.HELMET, 1,
				ArmorType.CHESTPLATE, 3,
				ArmorType.LEGGINGS, 2,
				ArmorType.BOOTS, 1
			),
			10, // enchantment value
			net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_LEATHER, // equipSound (NOT null!)
			0.0f, // toughness
			0.0f, // knockbackResistance
			net.minecraft.tags.ItemTags.REPAIRS_LEATHER_ARMOR, // repairIngredient tag (NOT null!)
			EquipmentAssets.LEATHER // asset ID
		);

		// Register Pressure Suit (Full Set) — and store instances
		pressureSuitHelmet = Registry.register(BuiltInRegistries.ITEM, PRESSURE_SUIT_HELMET,
			new Item(new Item.Properties()
				.humanoidArmor(armorMaterial, ArmorType.HELMET)
				.setId(ResourceKey.create(Registries.ITEM, PRESSURE_SUIT_HELMET))));
		pressureSuitChestplate = Registry.register(BuiltInRegistries.ITEM, PRESSURE_SUIT_CHESTPLATE,
			new Item(new Item.Properties()
				.humanoidArmor(armorMaterial, ArmorType.CHESTPLATE)
				.setId(ResourceKey.create(Registries.ITEM, PRESSURE_SUIT_CHESTPLATE))));
		pressureSuitLeggings = Registry.register(BuiltInRegistries.ITEM, PRESSURE_SUIT_LEGGINGS,
			new Item(new Item.Properties()
				.humanoidArmor(armorMaterial, ArmorType.LEGGINGS)
				.setId(ResourceKey.create(Registries.ITEM, PRESSURE_SUIT_LEGGINGS))));
		pressureSuitBoots = Registry.register(BuiltInRegistries.ITEM, PRESSURE_SUIT_BOOTS,
			new Item(new Item.Properties()
				.humanoidArmor(armorMaterial, ArmorType.BOOTS)
				.setId(ResourceKey.create(Registries.ITEM, PRESSURE_SUIT_BOOTS))));

		// Register Carbon Fiber materials — and store instances
		carbonFiberItem = Registry.register(BuiltInRegistries.ITEM, CARBON_FIBER,
			new Item(new Item.Properties()
				.setId(ResourceKey.create(Registries.ITEM, CARBON_FIBER))));
		carbonFiberPlateItem = Registry.register(BuiltInRegistries.ITEM, CARBON_FIBER_PLATE,
			new Item(new Item.Properties()
				.setId(ResourceKey.create(Registries.ITEM, CARBON_FIBER_PLATE))));

		// Pressure Seal enchantment is registered via datapack JSON
		LOGGER.info("Pressure Seal enchantment defined via datapack!");

		// Add items to creative tabs so they appear in inventory
		registerCreativeTabs();

		// Inject pressure suit pieces into vanilla loot tables
		registerLootInjection();

		// Run once/second (20 ticks)
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			long time = server.overworld().getLevelData().getGameTime();
			if ((time % 20) != 0) return;

			for (ServerLevel world : server.getAllLevels()) {
				for (Player player : world.players()) {
					if (player.isCreative() || player.isSpectator()) continue;

					// Low pressure damage (high altitude)
					float lowDps = AtmosphereManager.computeAtmosphereDamagePerSecond(world, player);
					if (lowDps > 0f) {
						player.hurt(lowPressureDamage(world), lowDps);
					}

					// High pressure damage (deep water)
					float highDps = WaterPressureManager.computeWaterPressureDamage(world, player);
					if (highDps > 0f) {
						// Keep air supply full so the player dies from pressure, not drowning
						player.setAirSupply(player.getMaxAirSupply());
						player.hurt(highPressureDamage(world), highDps);
					}
				}
			}
		});

		LOGGER.info("Better Aerodynamics: pressure suit and dual damage system registered!");
	}

	/** Register a custom creative tab containing all mod items. */
	private void registerCreativeTabs() {
		ResourceKey<CreativeModeTab> tabKey = ResourceKey.create(
			Registries.CREATIVE_MODE_TAB, id("betteraerodynamics_tab"));

		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, tabKey,
			CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
				.title(Component.translatable("itemGroup.betteraerodynamics"))
				.icon(() -> new ItemStack(pressureSuitChestplate))
				.displayItems((params, output) -> {
					output.accept(pressureSuitHelmet);
					output.accept(pressureSuitChestplate);
					output.accept(pressureSuitLeggings);
					output.accept(pressureSuitBoots);
					output.accept(carbonFiberItem);
					output.accept(carbonFiberPlateItem);
				})
				.build());

		LOGGER.info("Custom creative tab registered");
	}

	/**
	 * Inject pressure suit pieces into vanilla loot tables so they appear
	 * naturally in chests. Each chest rolls 0-2 random pressure suit pieces.
	 */
	private void registerLootInjection() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			if (!source.isBuiltin()) return;
			if (!isTargetTable(key)) return;

			var helmetRef     = BuiltInRegistries.ITEM.get(PRESSURE_SUIT_HELMET);
			var chestplateRef = BuiltInRegistries.ITEM.get(PRESSURE_SUIT_CHESTPLATE);
			var leggingsRef   = BuiltInRegistries.ITEM.get(PRESSURE_SUIT_LEGGINGS);
			var bootsRef      = BuiltInRegistries.ITEM.get(PRESSURE_SUIT_BOOTS);

			if (helmetRef.isEmpty() || chestplateRef.isEmpty() || leggingsRef.isEmpty() || bootsRef.isEmpty()) {
				LOGGER.warn("Pressure suit items not found in registry — skipping loot injection");
				return;
			}

			Item helmet     = helmetRef.get().value();
			Item chestplate = chestplateRef.get().value();
			Item leggings   = leggingsRef.get().value();
			Item boots      = bootsRef.get().value();

			LootPool.Builder pool = LootPool.lootPool()
				.setRolls(UniformGenerator.between(0, 2))
				.add(LootItem.lootTableItem(helmet).setWeight(1).build())
				.add(LootItem.lootTableItem(chestplate).setWeight(1).build())
				.add(LootItem.lootTableItem(leggings).setWeight(1).build())
				.add(LootItem.lootTableItem(boots).setWeight(1).build());

			tableBuilder.pool(pool.build());
		});

		LOGGER.info("Pressure suit loot injection registered for {} loot tables", LOOT_TABLE_PATHS.length);
	}

	private DamageSource lowPressureDamage(ServerLevel world) {
		return world.damageSources().source(
			ResourceKey.create(Registries.DAMAGE_TYPE, id("low_pressure"))
		);
	}

	private DamageSource highPressureDamage(ServerLevel world) {
		return world.damageSources().source(
			ResourceKey.create(Registries.DAMAGE_TYPE, id("high_pressure"))
		);
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
