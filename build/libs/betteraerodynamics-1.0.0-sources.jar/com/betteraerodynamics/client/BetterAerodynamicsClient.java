package com.betteraerodynamics.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class BetterAerodynamicsClient implements ClientModInitializer {
    private static final String MOD_ID = "betteraerodynamics";

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
            Identifier.fromNamespaceAndPath(MOD_ID, "altimeter"),
            (extractor, deltaTracker) -> {
                Minecraft client = Minecraft.getInstance();
                if (client.player == null || client.level == null) return;
                if (client.options.hideGui) return;

                // Altitude calculation (matching AtmosphereManager.altitudeFeet)
                int seaLevel = client.level.getSeaLevel();
                double y = client.player.getY();
                double top = 320.0;
                double span = Math.max(1.0, top - seaLevel);
                double normalized = (y - seaLevel) / span;
                double feet = normalized * 29031.0;
                feet = Math.max(-2000.0, Math.min(100000.0, feet));
                double meters = feet * 0.3048;

                String text = String.format("Alt: %.0f ft / %.0f m", feet, meters);

                int textWidth = client.font.width(text);
                int x = extractor.guiWidth() - 10 - textWidth;
                int yPos = 20;

                extractor.text(client.font, text, x, yPos, 0xFFFFFF);
            }
        );
    }
}
