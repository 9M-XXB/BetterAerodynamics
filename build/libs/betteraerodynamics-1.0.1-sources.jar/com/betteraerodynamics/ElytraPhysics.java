package com.betteraerodynamics;

import com.betteraerodynamics.aero.AirfoilProfile;
import com.betteraerodynamics.aero.WingPhysics;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Bridges the aerodynamics engine into Minecraft elytra flight.
 *
 * <p>Every tick, for an elytra-flying player:
 * <ol>
 *   <li>Compute wing lift & drag via {@link WingPhysics}</li>
 *   <li>Convert lbf → Minecraft velocity units</li>
 *   <li>Apply drag opposite to velocity, lift upward</li>
 * </ol>
 *
 * <p>Result: elytra flight responds to speed, air density, and angle of attack.
 * Fast flight generates more lift, thin air at altitude reduces lift,
 * steep angles cause stall and rapid descent.
 */
public class ElytraPhysics {

    /** Wing config for elytra: hang-glider-like, moderate area + aspect ratio. */
    private static final WingPhysics.WingConfig ELYTRA_CONFIG = new WingPhysics.WingConfig(
        15.0,    // wingArea (ft²) — between glider and small aircraft
        5.0,     // aspectRatio — stubby fabric wings
        0.75,    // oswaldEfficiency
        0.010,   // cd0 — fabric drag
        1.3,     // clMax
        0.261799, // stallAngle (15° in radians)
        800.0    // maxLoad (lbf)
    );

    /** NACA 2412: 2% camber, 12% thickness — classic all-rounder airfoil. */
    private static final AirfoilProfile ELYTRA_AIRFOIL = new AirfoilProfile("2412", 50);

    /**
     * Conversion: lbf → Minecraft velocity delta per tick.
     * Tuned so ~50 mph glide at sea level produces roughly level flight.
     */
    private static final double LBF_TO_MC = 0.00008;

    /** Minimum speed (ft/s) below which aero forces disengage. */
    private static final double MIN_SPEED_FT_S = 20.0;

    /**
     * Apply aerodynamic lift and drag to an elytra-flying player.
     * Called once per tick from the server tick handler.
     */
    public static void applyToPlayer(ServerLevel world, Player player) {
        if (!player.isFallFlying()) return;
        if (player.onGround()) return;

        Vec3 velocity = player.getDeltaMovement();
        double speedBlocksPerTick = velocity.length();
        double speedFtS = speedBlocksPerTick * 3.28084 * 20.0;

        if (speedFtS < MIN_SPEED_FT_S) return;

        // Compute aerodynamic forces
        WingPhysics.WingForces forces = WingPhysics.computeForces(
            world, player, ELYTRA_CONFIG, ELYTRA_AIRFOIL);

        double dragLbf = forces.drag();
        double liftLbf = forces.lift();

        if (forces.stalled()) {
            // Stall: lift collapses → apply extra drag only
            dragLbf *= 2.5;
            liftLbf = 0;
        }

        // Convert to MC velocity deltas, with sanity caps
        double dragMc = Math.min(dragLbf * LBF_TO_MC, 0.15);
        double liftMc = Math.min(liftLbf * LBF_TO_MC, 0.12);

        // Drag: opposite to velocity direction (slows the player)
        if (speedBlocksPerTick > 0.001) {
            Vec3 dragDir = velocity.normalize().scale(-dragMc);
            player.addDeltaMovement(dragDir);
        }

        // Lift: upward (world Y+)
        if (liftMc > 0) {
            player.addDeltaMovement(new Vec3(0, liftMc, 0));
        }
    }
}
